import { Component } from '@angular/core';
import {AuthenticationService, Config, TokenPayLoad} from '../authentication.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})

export class LoginComponent {

  userd: TokenPayLoad = {
    name: '',
    password: ''
  };



  config: Config = {msg: ''} ;

  constructor(private auth: AuthenticationService, private router: Router) {}

  login() {
    this.auth.login(this.userd).subscribe(
      (resp: Config) => {
        this.config.msg = '';
        if (resp.msg === 'Brak takiego użytkownika.' || resp.msg === 'Zła weryfikacja.') {
          this.config.msg = resp.msg;
          this.userd.password = this.userd.name = '';
        } else {
          this.router.navigateByUrl('/main');
        }
      }
    );
  }

}
