import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable, of} from 'rxjs';

import { Router} from '@angular/router';
import {map} from 'rxjs/operators';
import {FlexAlignStyleBuilder} from '@angular/flex-layout';

export interface TokenPayLoad {
  name: string;
  password: string;
}

interface TokenResponse {
  token: string;
}

export interface Config {
  msg: string;
}

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {
  private token: string;
  private isadminuser: string;
  isloggedIn = false;
  exp;

  constructor(private http: HttpClient, private router: Router) {
    this.getExp();
  }

  private saveToken(token: string): void {
    localStorage.setItem('usertoken', token);
    this.token = token;
  }

  private getToken(): any {
    if (!this.token) {
      this.token = localStorage.getItem('usertoken');
    }
    return this.token;
  }

  private getExp(): any {
    try {
      if (!this.exp) {
        this.exp = localStorage.getItem('exp');
      }
      return this.exp;
    } catch (e) {
      return this.exp = '';
    }
  }

  public saveExp(exp: string): void {
    localStorage.setItem('exp', exp);
    this.exp = exp;
  }

  public saveisAdmin(isadminuser: string): void {
    localStorage.setItem('isAdmin', isadminuser);
    this.isadminuser = isadminuser;
  }

  public getisAdmin(): any {
    if (!this.isadminuser) {
      this.isadminuser = localStorage.getItem('isAdmin');
    }
    return this.isadminuser;
  }

  public profil(): Observable<any> {
    return this.http.post('/api/profil  ', {xaccesstoken: this.getToken()});
  }

  public isadmin(): Observable<any> {
    return this.http.post('/api/isadmin  ', {xaccesstoken: this.getToken()});
  }



  public login(user: TokenPayLoad): Observable<any> {
    const base = this.http.post('/api/login', user);

    const request = base.pipe(
      map( (data: any) => {
        if (data.token) {
          this.saveToken(data.token);
          this.isloggedIn = true;
          const like = {wai: '/'};
          const arlike = [];
          arlike.push(like);
          localStorage.setItem('wai', JSON.stringify(arlike));
          const payload = data.token.split('.')[1];
          const payload2 = window.atob(payload);
          const myexp = JSON.parse(payload2).exp;
          this.saveExp(myexp);
          this.isadmin().subscribe(r => {
            this.saveisAdmin(r.name);
          });
        }
        return data;
      })
    );
    return request;
  }

  public setwai() {
    const like = {wai: '/'};
    const arlike = [];
    arlike.push(like);
    localStorage.setItem('wai', JSON.stringify(arlike));
  }


  public isLoggedIn(): boolean {
    try {
      const e = Number(this.exp);
      const d = Number(Date.now() / 1000);
      const b: boolean = (e > d);
      if (this.isloggedIn === true)  {
           if (b === false) {
             if ( this.router.url !== '/') {
               this.logout();
               this.isloggedIn = false;
             }
           }
      }
      if (this.isloggedIn === true)  {
        if (b === false) {
          if ( this.router.url !== '/login') {
            this.logout();
            this.isloggedIn = false;
          }
        }
      }
      return b;
    } catch (e) {
    }
  }

  public logout(): void {
    this.saveToken('');
    this.saveExp('');
    window.localStorage.removeItem('usertoken');
    this.router.navigateByUrl('/login');
    window.location.reload();
  }

}
