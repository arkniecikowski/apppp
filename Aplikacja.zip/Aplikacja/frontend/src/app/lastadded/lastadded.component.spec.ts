import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastaddedComponent } from './lastadded.component';

describe('LastaddedComponent', () => {
  let component: LastaddedComponent;
  let fixture: ComponentFixture<LastaddedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastaddedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastaddedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
