import {ChangeDetectorRef, Injectable, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable, of} from 'rxjs';

import { SafeUrl } from '@angular/platform-browser/src/security/dom_sanitization_service';

@Injectable({
  providedIn: 'root'
})

export class LastaddedService {
  private token: string;
  private WAI: any;

  constructor(private http: HttpClient) {
    this.token = localStorage.getItem('usertoken');
  }

  public get_last_files(): Observable<any> {
    return this.http.post('/api/get_last_files ', {xaccesstoken: this.getToken(), wai: this.getWAI()});
  }

  public get_file_show(uid: any): Observable<any> {
    const formData = new FormData();
    formData.append('uid', uid);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_file_show', formData, {
      responseType: 'BinaryType' as 'json'
    });
  }

  public download_files(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('files', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/download_files', formData, {
      responseType: 'BinaryType' as 'json',
      observe: 'response',
      headers: ({downloadType: 'lastDownload'})
    });
  }



  private getWAI(): any {
    this.WAI = localStorage.getItem('wai');
    return this.WAI;
  }

  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem('usertoken');
    }
    return this.token;
  }
}
