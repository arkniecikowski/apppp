import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {HttpClient} from '@angular/common/http';
import {DomSanitizer} from '@angular/platform-browser';
import {ActivatedRoute, Router} from '@angular/router';
import {Files, MainFiles} from '../files/array/array.component';
import {LastaddedService} from './lastadded.service';


export interface Files {
  name: string;
  datatime: string;
}

export interface MainFiles {
  uid: string;
  name: string;
  datatime: string;
  fileExtension: string;
}

@Component({
  selector: 'app-lastadded',
  templateUrl: './lastadded.component.html',
  styleUrls: ['./lastadded.component.css']
})
export class LastaddedComponent implements OnInit {
  @Output() isSelected = new EventEmitter();
  @Output() OpenGallery = new EventEmitter();
  @Output() ReloadGallery = new EventEmitter();
  @Output() cellClick: EventEmitter<any> = new EventEmitter();
  highlightedRows = [];

  load = false;
  color = 'primary';
  mode = 'indeterminate';
  value = 50;
  bufferValue = 75;

  isOpen: boolean;
  showColumns: string[] = ['name', 'datatime'];
  showColumnsM: string[] = ['name'];
  mainDataSource = new Array<MainFiles>();
  showDataSource = new MatTableDataSource<Files>();
  selection = new SelectionModel<Files>(true, []);

  constructor(private http: HttpClient,
              private lastaddedservice: LastaddedService) {
  }

  ngOnInit(): void {
    this.getFiles();
  }


  ifText(element) {
    let ifFol = false;
    let aArray;
    this.mainDataSource.forEach( i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.fileExtension !== null) {
          aArray = i.fileExtension.split('/');
          if (aArray[0] === 'text') {
            ifFol = true;
          }
        }
      }
    });
    return ifFol;
  }

  ifVideo(element) {
    let ifFol = false;
    let aArray;
    this.mainDataSource.forEach(i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.fileExtension !== null) {
          aArray = i.fileExtension.split('/');
          if (aArray[0] === 'video') {
            ifFol = true;
          }
        }
      }
    });
    return ifFol;
  }

  ifImage(element) {
    let ifFol = false;
    let aArray;
    this.mainDataSource.forEach(i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.fileExtension !== null) {
          aArray = i.fileExtension.split('/');
          if (aArray[0] === 'image') {
            ifFol = true;
          }
        }
      }
    });
    return ifFol;
  }

  /* UID zaznaczonych plików */
  public getSelectedFilesUID() {
    const start = [];
    const selFiles: any = [];
    try {
      this.mainDataSource.forEach( i => {
        this.selection.selected.forEach(y => {
          if (i.name === y.name && i.datatime === y.datatime) {
            selFiles.push(i.uid);
          }
        });
      });
      return selFiles;
    } catch (e) {
      return start;
    }
  }

  getshowDataSource() {
    return this.showDataSource;
  }


  sethighlightedRows(row) {
    if (this.highlightedRows.includes(row)) {
      const newarray = [];
      this.highlightedRows.forEach(o => {
        if (o !== row) {
          newarray.push(o);
        }
      });
      this.highlightedRows = newarray;
    } else {
      this.highlightedRows.push(row);
    }
  }


  /* Pobierz pliki */
  getFiles() {
    this.selection.clear();
    this.setLoad();
    this.lastaddedservice.get_last_files().subscribe(
      result => {
        this.setLoad();
        this.mainDataSource = result.files;
        this.makeShowDataSource(this.mainDataSource);
      }
    );
  }

  /** Tworzenie porządku w tabeli do wyświetlania */
  makeShowDataSource(mainData: Array<MainFiles>) {
    const filesArray = mainData.map(o => {
      return {name: o.name, datatime: o.datatime};
    });
    this.showDataSource = new MatTableDataSource<Files>(filesArray);
  }

  emitSelect() {
    this.isSelected.emit(this.selection.hasValue());
  }

  setLoad() {
    if (this.load === false) {
      this.load = true;
    } else {
      this.load = false;
    }
  }
  /* Otwieranie plików */
  openFile(myname) {
    this.isOpen = true;
    this.selection.clear();
    const myfile = this.mainDataSource.find(x => x.name === myname.name).uid;
    const myfile2 = this.mainDataSource.find(x => x.name === myname.name);
    console.log(myfile);
    const tabWindowId = window.open('about:blank', '_blank');
    this.lastaddedservice.get_file_show(myfile).subscribe(
      (val: BinaryType) => {

        if (myfile2.isFolder) {
          const newwai = JSON.parse(val).wai;
          localStorage.setItem('wai', newwai);
          this.getFiles();
        } else {
          const byteC = atob(val);
          const byteN = new Array(byteC.length);
          for (let i = 0; i < byteC.length; i++) {
            byteN[i] = byteC.charCodeAt(i);
          }
          const byteA = new Uint8Array(byteN);
          const b = new Blob([byteA], { type: myfile2.fileExtension });
          const fileURL = URL.createObjectURL(b);
          tabWindowId.location.href = fileURL;
        }
        this.highlightedRows = [];
        this.selection.clear();
        this.isSelected.emit(false);
      });
  }

  clickFile(row) {
    if (!this.isOpen) {
      this.selection.toggle(row);
      this.isOpen = false;
    }
    this.isOpen = false;
    this.isSelected.emit(this.selection.hasValue());
  }

  RefreshSelectedAndNav() {
    this.isSelected.emit(false);
    this.getFiles();
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.showDataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.showDataSource.data.forEach(row => this.selection.select(row));
  }
}
