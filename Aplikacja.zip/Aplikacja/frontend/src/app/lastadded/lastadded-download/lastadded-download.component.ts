import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {FileService} from '../../files/file.service';
import {saveAs as importedSaveAs} from 'file-saver';
import {MAT_TOOLTIP_DEFAULT_OPTIONS, MatTooltipDefaultOptions} from '@angular/material';
import {LastaddedService} from '../lastadded.service';

export const myCustomTooltipDefaults: MatTooltipDefaultOptions = {
  showDelay: 1000,
  hideDelay: 1000,
  touchendHideDelay: 1000,
};

@Component({
  selector: 'app-lastadded-download',
  templateUrl: './lastadded-download.component.html',
  styleUrls: ['./lastadded-download.component.css'],
  providers: [
    {provide: MAT_TOOLTIP_DEFAULT_OPTIONS, useValue: myCustomTooltipDefaults}
  ],
})
export class LastaddedDownloadComponent implements OnInit {
  @Input() files;
  @Output() RefreshTable = new EventEmitter();
  @Output() Loading = new EventEmitter();

  constructor(private http: HttpClient, private lastaddedservice: LastaddedService) { }

  downloadFile() {
    this.Loading.emit();
    return this.lastaddedservice.download_files(this.files).subscribe((o: HttpResponse<any>) => {
      this.mySaveFiles(o);
      this.Loading.emit();
      this.RefreshTable.emit();
    });
  }

  mySaveFiles(o: any) {
    const ResponseName = o.headers.get('name');
    const ResponseType = o.headers.get('typ');
    const byteC = atob(o.body);
    const byteN = new Array(byteC.length);

    for (let i = 0; i < byteC.length; i++) {
      byteN[i] = byteC.charCodeAt(i);
    }
    const byteA = new Uint8Array(byteN);
    const ablob = new Blob([byteA], {type: ResponseType});
    const aname = ResponseName;
    importedSaveAs(ablob, aname);
  }
  ngOnInit() {

  }

}
