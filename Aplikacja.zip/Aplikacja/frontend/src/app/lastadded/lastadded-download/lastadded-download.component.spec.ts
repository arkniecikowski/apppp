import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastaddedDownloadComponent } from './lastadded-download.component';

describe('LastaddedDownloadComponent', () => {
  let component: LastaddedDownloadComponent;
  let fixture: ComponentFixture<LastaddedDownloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastaddedDownloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastaddedDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
