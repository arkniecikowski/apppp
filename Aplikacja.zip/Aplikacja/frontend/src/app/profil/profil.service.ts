import {ChangeDetectorRef, Injectable, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable, of} from 'rxjs';

import { SafeUrl } from '@angular/platform-browser/src/security/dom_sanitization_service';

@Injectable({
  providedIn: 'root'
})

export class ProfilService {
  private token: string;
  private WAI: any;

  constructor(private http: HttpClient) {
    this.token = localStorage.getItem('usertoken');
  }



  public add_user(name: string, pass: string, isadmin: string): Observable<any> {
    const formData = new FormData();
    formData.append('name', name);
    formData.append('pass', pass);
    formData.append('isadmin', isadmin);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/add_user', formData);
  }

  public change_password(newpass: string): Observable<any> {
    const formData = new FormData();
    formData.append('newpass', newpass);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/change_password', formData);
  }

  public get_user_details(): Observable<any> {
    const formData = new FormData();
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_user_details', formData, {
      headers: ({downloadType: 'detailNormal'})
    });
  }

  public get_user_details_admin(user: any): Observable<any> {
    const formData = new FormData();
    formData.append('user', user);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_user_details', formData, {
      headers: ({downloadType: 'detailAdmin'})
    });
  }

  public add_avatar(file: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/add_avatar', formData);
  }

  public change_role(user: any): Observable<any> {
    const formData = new FormData();
    formData.append('user', user);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/change_role', formData);
  }

  public get_avatar(): Observable<any> {
    const formData = new FormData();
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_avatar', formData);
  }

  public delete_user(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('user', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/delete_user', formData);
  }


  public change_password_admin(user: string, newpass: string): Observable<any> {
    const formData = new FormData();
    formData.append('user_id', user);
    formData.append('newpass', newpass);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/change_password_admin', formData);
  }

  private getWAI(): any {
    this.WAI = localStorage.getItem('wai');
    return this.WAI;
  }

  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem('usertoken');
    }
    return this.token;
  }

}
