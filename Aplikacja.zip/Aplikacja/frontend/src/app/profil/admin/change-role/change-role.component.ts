import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ProfilService} from '../../profil.service';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatSnackBar} from '@angular/material';
import {DialogData} from '../../user/change-psas/change-psas.component';

@Component({
  selector: 'app-change-role',
  templateUrl: './change-role.component.html',
  styleUrls: ['./change-role.component.css']
})
export class ChangeRoleComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  @Input() user;

  check: boolean ;
  constructor(private http: HttpClient,
              private profilservice: ProfilService,
              public dialog: MatDialog,
              private  snackBar: MatSnackBar) { }

  openDialog(): void {

    const dialogRef = this.dialog.open(ChangeRoleDialogComponent, {
      width: '250px',
      data: {check: this.check}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === false) {
        this.profilservice.change_role(this.user).subscribe( res => {
          this.snackBar.open(res.msg, ' ', {duration: 4000});
          this.RefreshTable.emit();
        });
      }
    });
  }

isDis() {
    if (this.user.length === 1) {
      return false;
    } else {
      return true;
    }
  }

  ngOnInit() {}

}

@Component({
  selector: 'app-change-role-dialog',
  templateUrl: './change-role-dialog.html',
})

export class ChangeRoleDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ChangeRoleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}
