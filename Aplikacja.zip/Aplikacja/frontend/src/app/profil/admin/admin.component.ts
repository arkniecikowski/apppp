import { Component, EventEmitter,  OnInit, Output} from '@angular/core';
import { MatDialog,  MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../../files/file.service';
import {ProfilService} from '../profil.service';
import {DomSanitizer} from '@angular/platform-browser';

export interface LiteResponse  {
  select: any;
  name: string;
  role: string;
}

export interface MainResponse {
  name: string;
  role: string;
  public_id: string;
  select: string;
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  @Output() isSelected = new EventEmitter();
  @Output() RefreshTable = new EventEmitter();
  isOpen: boolean;
  highlightedRows = [];

  showColumns: string[] = ['select', 'name', 'role'];
  mainDataSource = new Array<MainResponse>();
  showDataSource = new MatTableDataSource<LiteResponse>();

  selection = new SelectionModel<LiteResponse>(true, []);

  selectedFiles: File;

  constructor(
              private http: HttpClient,
              private fileservice: FileService,
              private profilservice: ProfilService,
              public dialog: MatDialog,
              private sanitizer: DomSanitizer) {
  }

  ngOnInit() {
    this.getFiles();
  }

  /* UID zaznaczonych plików */
  public getSelectedUsers() {
    const start = [];
    const selFiles: any = [];
    try {
      this.mainDataSource.forEach( i => {
        this.selection.selected.forEach(y => {
          if (i.name === y.name) {
            selFiles.push(i.public_id);
          }
        });
      });
      return selFiles;
    } catch (e) {
      return start;
    }
  }

  clickFile(row, i) {
    if (!this.isOpen) {
      this.selection.toggle(row);
      this.isSelected.emit();
      this.isOpen = false;
    }
    this.isOpen = false;
    this.isSelected.emit(this.selection.hasValue());
  }

  sethighlightedRows(row) {
    if (this.highlightedRows.includes(row)) {
      const newarray = [];
      this.highlightedRows.forEach(o => {
        if (o !== row) {
          newarray.push(o);
        }
      });
      this.highlightedRows = newarray;
    } else {
      this.highlightedRows.push(row);
    }
  }

  getFiles() {
    this.selection.clear();
    this.fileservice.get_users().subscribe(
      result => {
        this.mainDataSource = result.users;
        this.makeShowDataSource(this.mainDataSource);
      }
    );
  }

  emitSelect() {
    this.isSelected.emit(this.selection.hasValue());
  }

  RefreshSelectedAndNav() {
    this.isSelected.emit(false);
  }

  makeShowDataSource(mainData: Array<MainResponse>) {
    const filesArray = mainData.map(o => {
      const ns = this.sanitizer.bypassSecurityTrustUrl(o.select);
      return {select: ns, name: o.name, role: o.role};
    });
    this.showDataSource = new MatTableDataSource<LiteResponse>(filesArray);
  }

  onFileSelected(event) {
    this.selectedFiles = event.target.files[0];
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.showDataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.showDataSource.data.forEach(row => this.selection.select(row));
  }
}
