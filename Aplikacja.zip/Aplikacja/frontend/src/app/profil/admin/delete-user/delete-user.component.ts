import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {HttpClient} from '@angular/common/http';
import {ProfilService} from '../../profil.service';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  @Input() user;

  constructor(private http: HttpClient, private profilservice: ProfilService, public dialog: MatDialog) { }
  openDialog(): void {

    const dialogRef = this.dialog.open(DeleteUserDialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log(this.user);
        this.profilservice.delete_user(this.user).subscribe( res => {
          console.log(res);
          this.RefreshTable.emit();
        });
      } else {
        this.RefreshTable.emit();
      }
    });
  }
  ngOnInit() {}

}

@Component({
  selector: 'app-delete-user-dialog',
  templateUrl: './delete-user-dialog.html',
})
export class DeleteUserDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<DeleteUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
