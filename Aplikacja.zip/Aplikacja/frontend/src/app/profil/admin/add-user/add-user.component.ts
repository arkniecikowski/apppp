import {Component, EventEmitter, Inject, OnInit, Output} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatSnackBar} from '@angular/material';
import {ProfilService} from '../../profil.service';

export interface DialogData {
  name: string;
  pass: string;
  isAdmin: string;
}

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit{
  @Output() RefreshTable = new EventEmitter();
  name: string;
  pass: string;
  isAdmin: string;


  constructor(private http: HttpClient,
              private profil: ProfilService,
              public dialog: MatDialog,
              private  snackBar: MatSnackBar) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(AddUserDialogComponent, {
      width: '250px',
      data:
        {
          name: this.name,
          pass: this.pass,
          isAdmin: this.isAdmin
        }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.profil.add_user(result[0], result[1], String(result[2])).subscribe( res => {
          this.snackBar.open(res.msg,
            ' ', {duration: 4000});
          this.RefreshTable.emit();
        });
      }
    });
  }

  ngOnInit(): void {
  }
}

@Component({
  selector: 'app-add-user-dialog',
  templateUrl: './add-user-dialog.component.html',
})

export class AddUserDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<AddUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}
