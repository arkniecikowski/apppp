import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ProfilService} from '../../profil.service';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatSnackBar} from '@angular/material';
import { DialogData} from '../../user/change-psas/change-psas.component';

@Component({
  selector: 'app-change-pass',
  templateUrl: './change-pass.component.html',
  styleUrls: ['./change-pass.component.css']
})
export class ChangePassComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  @Input() user;

  newpassword: string ;

  constructor(private http: HttpClient,
              private profilservice: ProfilService,
              public dialog: MatDialog,
              private snackBar: MatSnackBar) { }

  openDialog(): void {

    const dialogRef = this.dialog.open(ChangePassDialogComponent, {
      width: '250px',
      data: {newpassword: this.newpassword}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.profilservice.change_password_admin(this.user, result).subscribe( res => {
        this.snackBar.open(res.msg, ' ', {duration: 4000});
        this.RefreshTable.emit();
      });
    });
  }
  ngOnInit() {
  }
}

@Component({
  selector: 'app-change-my-pass-dialog',
  templateUrl: './change-pass-dialog.html',
})

export class ChangePassDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<ChangePassDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}

