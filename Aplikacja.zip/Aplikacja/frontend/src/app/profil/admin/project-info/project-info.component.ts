import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../../../files/file.service';
import {SharedService} from '../../../shared/shared.service';
import {ProfilService} from '../../profil.service';

@Component({
  selector: 'app-project-info',
  templateUrl: './project-info.component.html',
  styleUrls: ['./project-info.component.css']
})
export class ProjectInfoComponent implements OnInit {
  @Input() user;
  @Output() RefreshTable = new EventEmitter();


  constructor(public dialog: MatDialog) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(ProjectInfoDialogComponent, {
      width: '80%',
      data: this.user
    });

    dialogRef.afterClosed().subscribe(result => {
    this.RefreshTable.emit();
    });
  }

  ngOnInit() {}
}


export interface MainResponse {
  name: string;
  detail: string;
}


@Component({
  selector: 'app-info-dialog',
  templateUrl: './project-info-dialog.html',
  styleUrls: ['./project-info.component.css']
})

export class ProjectInfoDialogComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  highlightedRows = [];

  showColumns: string[] = ['name', 'detail'];
  showDataSource = new MatTableDataSource<MainResponse>();
  mainDataSource = new Array<MainResponse>();
  selection = new SelectionModel<MainResponse>(true, []);

  constructor(public dialogRef: MatDialogRef<ProjectInfoDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private http: HttpClient,
              private fileservice: FileService,
              private sharedService: SharedService,
              private profilservice: ProfilService,
              public dialog: MatDialog) {
  }


  ngOnInit() {
    this.getFiles();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  getFiles() {
    this.selection.clear();
    this.profilservice.get_user_details_admin(this.data).subscribe(
      result => {
        console.log(result);
        this.showDataSource = result.details;
        console.log(this.showDataSource);
      }
    );
  }

}
