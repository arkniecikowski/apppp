import {AfterViewInit, Component, OnInit} from '@angular/core';
import {AuthenticationService} from '../authentication.service';
import {ProfilService} from './profil.service';
import {DomSanitizer, SafeUrl} from '@angular/platform-browser';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.css']
})

export class ProfilComponent implements OnInit, AfterViewInit {
imie: any = {name: ''};
avatar: any = '';

  constructor(private auth: AuthenticationService,
              private profilservice: ProfilService,
              private sanitizer: DomSanitizer) {
    this.auth.profil().subscribe(
      (resp: any) => {
        if (resp.name.length > 14) {
          let newimie = resp.name.substr(0, 13);
          newimie = newimie + '...';
          this.imie.name = newimie;
        } else {
          this.imie.name = resp.name;
        }

        },
      (err) => {console.log(err); }
    );
  }

  reloadAvatar() {
    this.profilservice.get_avatar().subscribe(r => {
      const ns = this.sanitizer.bypassSecurityTrustUrl(r.avatar);
      this.avatar = ns;
    });
    console.log('ok');
  }

  ngAfterViewInit() {

  }

  ngOnInit() {
    this.profilservice.get_avatar().subscribe(r => {
      const ns = this.sanitizer.bypassSecurityTrustUrl(r.avatar);
      this.avatar = ns;
    });
  }

}
