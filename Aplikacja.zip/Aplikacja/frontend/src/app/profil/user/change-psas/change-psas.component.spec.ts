import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangePsasComponent } from './change-psas.component';

describe('ChangePsasComponent', () => {
  let component: ChangePsasComponent;
  let fixture: ComponentFixture<ChangePsasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangePsasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePsasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
