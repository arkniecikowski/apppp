import {Component, Inject, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatSnackBar} from '@angular/material';
import {ProfilService} from '../../profil.service';

export interface DialogData {
  newpassword: string;
}

@Component({
  selector: 'app-change-psas',
  templateUrl: './change-psas.component.html',
  styleUrls: ['./change-psas.component.css']
})
export class ChangePsasComponent implements OnInit {
  newpassword: string ;

  constructor(private http: HttpClient,
              private profilservice: ProfilService,
              public dialog: MatDialog,
              private snackBar: MatSnackBar) { }

  openDialog(): void {

      const dialogRef = this.dialog.open(ChangeMyPassDialogComponent, {
        width: '250px',
        data: {newpassword: this.newpassword}
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log(result);
        if (result) {
          this.profilservice.change_password(result).subscribe( res => {
            this.snackBar.open(res.msg, ' ', {duration: 4000});
          });
        };
      });
  }
  ngOnInit() {

  }
}

@Component({
  selector: 'app-change-my-pass-dialog',
  templateUrl: './change-my-pass-dialog.component.html',
})

export class ChangeMyPassDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<ChangeMyPassDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
