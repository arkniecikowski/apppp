import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../authentication.service';
import {ProfilService} from '../profil.service';
import { MatTableDataSource} from '@angular/material';
import { MainResponse} from '../../shared/shared.component';



export interface MainResponse {
  name: string;
  detail: string;
}

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  showColumns: string[] = ['name', 'detail'];
  showDataSource = new MatTableDataSource<MainResponse>();

  constructor(private auth: AuthenticationService,
              private profilservice: ProfilService) {}

  ngOnInit() {
    this.getFiles();
  }

  /* Pobierz pliki */
  getFiles() {
    this.profilservice.get_user_details().subscribe(
      result => {
        this.showDataSource = result.details;
      }
    );
  }

}

