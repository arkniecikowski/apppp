import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {ProfilService} from '../../profil.service';
import {MatSnackBar} from '@angular/material';

@Component({
  selector: 'app-add-avatar',
  templateUrl: './add-avatar.component.html',
  styleUrls: ['./add-avatar.component.css']
})
export class AddAvatarComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  selectedFile;

  constructor(private profileservice: ProfilService,
              private snackBar: MatSnackBar) { }
  ngOnInit() {
  }

  onFileSelected(event) {
    console.log(event.target.files[0]);
    this.selectedFile = event.target.files[0];
    this.onUpload();
    this.RefreshTable.emit();
  }

  onUpload() {
  this.RefreshTable.emit();
  this.profileservice.add_avatar(this.selectedFile)
    .subscribe(res => {
      this.snackBar.open(res.msg, ' ', {duration: 4000});
      this.RefreshTable.emit();
    });
  }
}
