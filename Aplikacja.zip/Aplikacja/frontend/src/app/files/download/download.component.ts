import {Component, EventEmitter, Input,  Output} from '@angular/core';
import {saveAs as importedSaveAs} from 'file-saver';
import {MAT_TOOLTIP_DEFAULT_OPTIONS, MatTooltipDefaultOptions} from '@angular/material';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {FileService} from '../file.service';

export const myCustomTooltipDefaults: MatTooltipDefaultOptions = {
  showDelay: 1000,
  hideDelay: 1000,
  touchendHideDelay: 1000,
};

@Component({
  selector: 'app-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.css'],
  providers: [
    {provide: MAT_TOOLTIP_DEFAULT_OPTIONS, useValue: myCustomTooltipDefaults}
  ],
})

export class DownloadComponent {
  @Input() files;
  @Output() Loading = new EventEmitter();
  @Output() RefreshTable = new EventEmitter();

  constructor(private http: HttpClient, private fileservice: FileService) { }

  downloadFile() {
    this.Loading.emit();
    return this.fileservice.download_files(this.files).subscribe((o: HttpResponse<any>) => {
      this.mySaveFiles(o);
      this.Loading.emit();
      this.RefreshTable.emit();
    });
  }

  mySaveFiles(o: any) {
    const ResponseName = o.headers.get('name');
    const ResponseType = o.headers.get('typ');
    const byteC = atob(o.body);
    const byteN = new Array(byteC.length);

    for (let i = 0; i < byteC.length; i++) {
      byteN[i] = byteC.charCodeAt(i);
    }
    const byteA = new Uint8Array(byteN);
    const ablob = new Blob([byteA], {type: ResponseType});
    const aname = ResponseName;

    importedSaveAs(ablob, aname);
  }

}
