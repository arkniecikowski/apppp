import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Observable, Subscription} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../file.service';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})

export class BreadcrumbComponent implements OnInit, OnDestroy {
  private eventsSubscription: Subscription;

  @Input() events: Observable<void>;
  @Input() files;
  @Output() RefreshTable = new EventEmitter();

  breadCrumbsPaths = [];
  breadCrumbsPathsActive;

  breadValueShow = [];
  breadLastValueShow = [];

  constructor(private http: HttpClient, private fileservice: FileService) {
    this.breadCrumbsPathsActive = {id: 0, wai: 'All'};
  }

  changeBreadNameUID() {
    return this.fileservice.get_names(JSON.stringify(this.breadCrumbsPaths), JSON.stringify(this.breadCrumbsPathsActive)).subscribe( o => {
      const bodyBreadCrumb = JSON.parse(o.dumpOutBody);
      const lastBreadCrumb = JSON.parse(o.dumpOutLast);

      if (+lastBreadCrumb.length === 0) {
        this.breadLastValueShow = bodyBreadCrumb[0];
        this.breadValueShow = [];
      } else {
        this.breadValueShow = JSON.parse(o.dumpOutBody);
        this.breadLastValueShow = JSON.parse(o.dumpOutLast)[0];
      }
    });
  }

  makeBreadCrumb() {
    let idx = 0;
    this.breadCrumbsPaths = [];
    this.breadCrumbsPathsActive = '';
    const waiArray = JSON.parse(localStorage.getItem('wai'));
    waiArray.forEach((o: any) => {
      if (waiArray.length === 1) {
        this.breadCrumbsPathsActive = {id: 0, wai: 'All'};
      } else if (o.wai === waiArray[waiArray.length - 1].wai) {
        this.breadCrumbsPathsActive = {id: waiArray.length, wai: (o.wai).substr(0, o.wai.length - 1)};
        this.breadCrumbsPaths[0] = {id: 0, wai: 'All'};
      } else {

        this.breadCrumbsPaths.push({id: idx, wai: (o.wai).substr(0, o.wai.length - 1) });
        idx += 1;
      }
    });
    this.changeBreadNameUID();
  }

  changeBreadCrumbDestination(x) {
    const waiArray = JSON.parse(localStorage.getItem('wai'));
    const wai = [];
    for (let i = 0; i <= x.id; i++) {
      wai.push(waiArray[i]);
    }
    localStorage.setItem('wai', JSON.stringify(wai));
    this.RefreshTable.emit();
    this.makeBreadCrumb();
  }

  ngOnInit() {
    this.makeBreadCrumb();
    this.changeBreadNameUID();
    this.eventsSubscription = this.events.subscribe(() => {
      this.makeBreadCrumb();
      this.changeBreadNameUID();
    });
  }

  ngOnDestroy() {
    this.eventsSubscription.unsubscribe();
  }
}
