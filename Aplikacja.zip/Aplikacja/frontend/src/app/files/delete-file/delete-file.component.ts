import {Component, EventEmitter, Inject, Input, Output} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../file.service';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatSnackBar} from '@angular/material';

@Component({
  selector: 'app-delete-file',
  templateUrl: './delete-file.component.html',
  styleUrls: ['./delete-file.component.css']
})

export class DeleteFileComponent {
  @Output() RefreshTable = new EventEmitter();
  @Input() files;

constructor(private http: HttpClient,
            private fileservice: FileService,
            public dialog: MatDialog,
            private snackBar: MatSnackBar) { }

  openDialog(): void {

    const dialogRef = this.dialog.open(DeleteFileDialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
      console.log(this.files);
      this.fileservice.delete_file(this.files).subscribe( res => {
        this.snackBar.open(res.msg, ' ', {duration: 4000});
        this.RefreshTable.emit();
      });
      } else {
        this.RefreshTable.emit();
      }
    });
  }
}

@Component({
  selector: 'app-delete-file-dialog',
  templateUrl: './delete-file-dialog.component.html',
})

export class DeleteFileDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<DeleteFileDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}

