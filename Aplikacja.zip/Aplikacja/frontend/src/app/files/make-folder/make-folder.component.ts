import {Component, EventEmitter, Inject, Output} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar} from '@angular/material';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../file.service';

export interface DialogData {
  folderName: string;
}

@Component({
  selector: 'app-make-folder',
  templateUrl: './make-folder.component.html',
  styleUrls: ['./make-folder.component.css']
})

export class MakeFolderComponent {
  @Output() RefreshTable = new EventEmitter();
  folderName: string;

  constructor(private http: HttpClient,
              private fileservice: FileService,
              public dialog: MatDialog,
              private snackBar: MatSnackBar) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(MakeFolderDialogComponent, {
      width: '250px',
      data: {folderName: this.folderName}
    });


    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.fileservice.make_folder(result).subscribe( res => {
          this.snackBar.open(res.msg, ' ', {duration: 4000});
          this.RefreshTable.emit();
        });
      } else {
        this.RefreshTable.emit();
      }
    });
  }
}

@Component({
  selector: 'app-make-folder-dialog',
  templateUrl: './make-folder-dialog.component.html',
})

export class MakeFolderDialogComponent {

constructor(
  public dialogRef: MatDialogRef<MakeFolderDialogComponent>,
  @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

onNoClick(): void {
  this.dialogRef.close();
}

}


