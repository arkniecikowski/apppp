import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakeFolderComponent } from './make-folder.component';

describe('MakeFolderComponent', () => {
  let component: MakeFolderComponent;
  let fixture: ComponentFixture<MakeFolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakeFolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakeFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
