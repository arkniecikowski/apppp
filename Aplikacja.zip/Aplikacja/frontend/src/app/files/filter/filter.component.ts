import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  @Input() files;
  showDataSource: any = [];

  constructor() { }

  ngOnInit() {
  }

  applyFilter(filterValue: string) {
    this.files.filter = filterValue.trim().toLowerCase();
  }
}
