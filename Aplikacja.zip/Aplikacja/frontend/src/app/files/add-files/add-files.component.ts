import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {FileService} from '../file.service';
import {MatDialog, MatSnackBar} from '@angular/material';

@Component({
  selector: 'app-add-files',
  templateUrl: './add-files.component.html',
  styleUrls: ['./add-files.component.css']
})
export class AddFilesComponent implements OnInit {
@Output() RefreshTable = new EventEmitter();
@Output() Loading = new EventEmitter();

selectedFile: FileList = null;
selectedFolder: FileList = null;

  constructor(private http: HttpClient,
              private fileservice: FileService,
              private snackBar: MatSnackBar) { }

  ngOnInit() { }

  onFileSelected(event) {
    console.log(event.target.files);
    this.selectedFile = event.target.files;
    this.onUpload();
    // this.RefreshTable.emit();
  }

  onFolderSelected(event) {
    console.log(event.target.files);
    this.selectedFolder = (event.target.files);
    this.onUpload();
    // this.RefreshTable.emit();
  }

  onUpload() {
    console.log(this.selectedFile);
    if (this.selectedFile) {
      this.snackBar.open('Trwa dodawanie plików...');
      this.Loading.emit();
      this.fileservice.add_file(this.selectedFile)
        .subscribe(res => {
          this.Loading.emit();
          this.snackBar.open(res.msg, ' ', {duration: 4000});
          this.RefreshTable.emit();
        });
    }
    if (this.selectedFolder) {
      this.snackBar.open('Trwa dodawanie plików...');
      this.Loading.emit();
      this.fileservice.add_folder(this.selectedFolder)
        .subscribe( res => {
          this.Loading.emit();
          this.snackBar.open(res.msg, ' ', {duration: 4000});
          this.RefreshTable.emit();
        });
    }
    console.log('saas');
  }

}
