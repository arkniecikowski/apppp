import {AfterViewInit, Component, EventEmitter, OnInit, Output} from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../file.service';
import {DomSanitizer} from '@angular/platform-browser';
import {ActivatedRoute, Router} from '@angular/router';
import {Subject} from 'rxjs';

export interface Files {
  name: string;
  datatime: string;
}


export interface MainFiles {
  uid: string;
  name: string;
  datatime: string;
  isFolder: boolean;
  fileExtension: string;
}

@Component({
  selector: 'app-array',
  templateUrl: './array.component.html',
  styleUrls: ['./array.component.css']
})

export class ArrayComponent implements OnInit, AfterViewInit {
  @Output() isSelected = new EventEmitter();
  @Output() OpenGallery = new EventEmitter();
  @Output() ReloadGallery = new EventEmitter();
  @Output() cellClick: EventEmitter<any> = new EventEmitter();

  load = false;
  color = 'primary';
  mode = 'indeterminate';
  value = 50;
  bufferValue = 75;

  private eventFolderOtwarty: Subject<void> = new Subject<void>();
  isOpen: boolean;
  showColumns: string[] = [ 'name', 'datatime'];
  showColumnsM: string[] = [ 'name'];
  highlightedRows = [];

  mainDataSource = new Array<MainFiles>();
  showDataSource = new MatTableDataSource<Files>();
  selection = new SelectionModel<Files>(true, []);

  constructor(private http: HttpClient,
              private fileservice: FileService) {
    this.getFiles();
  }

  ngAfterViewInit() {
    this.getFiles();
  }

ngOnInit(): void {
}

  sethighlightedRows(row) {
    if (this.highlightedRows.includes(row)) {
      const newarray = [];
      this.highlightedRows.forEach(o => {
        if (o !== row) {
          newarray.push(o);
        }
      });
      this.highlightedRows = newarray;
    } else {
      this.highlightedRows.push(row);
    }
  }

  setLoad() {
    if (this.load === false) {
      this.load = true;
    } else {
      this.load = false;
    }
  }


ifFolder(element) {
  let ifFol = false;
  this.mainDataSource.forEach( i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.isFolder) {
          ifFol = true;
        }
      }
  });
  return ifFol;
}


ifText(element) {
  let ifFol = false;
  let aArray;
  this.mainDataSource.forEach( i => {
    if (i.name === element.name && i.datatime === element.datatime) {
      if (i.fileExtension !== null) {
      aArray = i.fileExtension.split('/');
      if (aArray[0] === 'text') {
        ifFol = true;
      }
    }
    }
  });
  return ifFol;
}

ifImage(element) {
  let ifFol = false;
  let aArray;
  this.mainDataSource.forEach(i => {
    if (i.name === element.name && i.datatime === element.datatime) {
      if (i.fileExtension !== null) {
        aArray = i.fileExtension.split('/');
        if (aArray[0] === 'image') {
          ifFol = true;
        }
      }
    }
  });
  return ifFol;
}

ifVideo(element) {
  let ifFol = false;
  let aArray;
  this.mainDataSource.forEach(i => {
    if (i.name === element.name && i.datatime === element.datatime) {
      if (i.fileExtension !== null) {
        aArray = i.fileExtension.split('/');
        if (aArray[0] === 'video') {
          ifFol = true;
        }
      }
    }
  });
  return ifFol;
}


/* UID zaznaczonych plików */
public getSelectedFilesUID() {
  const start = [];
  const selFiles: any = [];
  try {
   this.mainDataSource.forEach( i => {
     this.selection.selected.forEach(y => {
       if (i.name === y.name && i.datatime === y.datatime) {
         selFiles.push(i.uid);
       }
     });
   });
   return selFiles;
 } catch (e) {
   return start;
 }
}

  /* UID zaznaczonych plików */
  getSelectedFilesisFolder() {
    const start = [];
    const selFiles: any = [];
    try {
      this.mainDataSource.forEach( i => {
        this.selection.selected.forEach(y => {
          if (i.name === y.name && i.datatime === y.datatime) {
            selFiles.push(i.isFolder);
          }
        });
      });
      return selFiles;
    } catch (e) {
      return start;
    }
  }

/* Pobierz pliki */
getFiles() {
  this.selection.clear();
  this.fileservice.get_files().subscribe(
    result => {
      this.mainDataSource = result.files;
      this.makeShowDataSource(this.mainDataSource);
    }
  );
}


/** Tworzenie porządku w tabeli do wyświetlania */
makeShowDataSource(mainData: Array<MainFiles>) {
  const foldersArray = mainData.filter(o =>
    o.isFolder === true).map(o => {
    return {name: o.name, datatime: o.datatime};
  });
  const filesArray = mainData.filter(o =>
    o.isFolder === false).map(o => {
    return {name: o.name, datatime: o.datatime};
  });
  const newArray = foldersArray.concat(filesArray);
  this.showDataSource = new MatTableDataSource<Files>(newArray);

}

getshowDataSource() {
  return this.showDataSource;
}


/* Otwieranie plików */
openFile(myname) {

  this.isOpen = true;
  this.selection.clear();
  const myfile = this.mainDataSource.find(x => x.name === myname.name).uid;
  const myfile2 = this.mainDataSource.find(x => x.name === myname.name);
  let tabWindowId;
  if (!myfile2.isFolder) {
    tabWindowId = window.open('about:blank', '_blank');
  }
  this.fileservice.get_file_and_show(myfile).subscribe(
    (val: BinaryType) => {
        if (myfile2.isFolder) {
          const newwai = JSON.parse(val).wai;
          localStorage.setItem('wai', newwai);
          this.getFiles();
          this.eventFolderOtwarty.next();
        } else {
          const byteC = atob(val);
          const byteN = new Array(byteC.length);
          for (let i = 0; i < byteC.length; i++) {
            byteN[i] = byteC.charCodeAt(i);
          }
          const byteA = new Uint8Array(byteN);
          const b = new Blob([byteA], { type: myfile2.fileExtension });
          const fileURL = URL.createObjectURL(b);
          tabWindowId.location.href = fileURL;
        }
        this.highlightedRows = [];
        this.selection.clear();
        this.isSelected.emit(false);
  });

}

  clickFile(row) {
    if (!this.isOpen) {
      this.selection.toggle(row);
      this.isOpen = false;
    }
    this.isOpen = false;
    this.isSelected.emit(this.selection.hasValue());
  }

  RefreshSelectedAndNav() {
    this.highlightedRows = [];
    this.selection.clear();
    this.isSelected.emit(false);
    this.getFiles();
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.showDataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.showDataSource.data.forEach(row => this.selection.select(row));
  }
}
