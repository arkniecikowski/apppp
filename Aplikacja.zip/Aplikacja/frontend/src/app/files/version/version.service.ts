import { Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable} from 'rxjs';

import { SafeUrl } from '@angular/platform-browser/src/security/dom_sanitization_service';

@Injectable({
  providedIn: 'root'
})

export class VersionService {
  private token: string;
  private WAI: any;

  constructor(private http: HttpClient) {
    this.token = localStorage.getItem('usertoken');
  }


  public delete_version(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/delete_version', formData);
  }

  public download_version(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/download_version', formData, {
      responseType: 'BinaryType' as 'json',
      observe: 'response'
    });
  }


  public get_version(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_versions', formData);
  }

  public add_version(m1: any, f1: any, message: any): Observable<any> {
    const formData = new FormData();
    formData.append('mainfile', m1);
    formData.append('newversion', f1);
    formData.append('message', message);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/add_version', formData);
  }

  get_version_and_show(u1: any): Observable<SafeUrl> {
    const formData = new FormData();
    formData.append('u1', u1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_version_and_show', formData, {
      responseType: 'BinaryType' as 'json'
    });
  }

  private getWAI(): any {
    this.WAI = localStorage.getItem('wai');
    return this.WAI;
  }

  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem('usertoken');
    }
    return this.token;
  }
}
