import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {saveAs as importedSaveAs} from 'file-saver';
import {VersionService} from '../version.service';

@Component({
  selector: 'app-version-nav',
  templateUrl: './version-nav.component.html',
  styleUrls: ['./version-nav.component.css']
})
export class VersionNavComponent {
  @Input() files;
  @Input() fileisFolder;
  @Output() RefreshTable = new EventEmitter();


  constructor(public dialog: MatDialog) {}

  isDis() {
  if (this.files.length === 1 && this.fileisFolder[0] === false) {
      return false;
    } else {
      return true;
    }
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(VersionNavDialogComponent, {
      width: '80%',
      data: this.files
    });

    dialogRef.afterClosed().subscribe(result => {
      this.RefreshTable.emit();
    });
    this.RefreshTable.emit();
  }
}

export interface VersionResponse  {
  message: string;
  datatime: string;
}

export interface MainVersionResponse {
  uid: string;
  file_uid: string;
  message: string;
  datatime: string;
  fileExtension: string;
}

@Component({
  selector: 'app-version-nav-dialog',
  templateUrl: './version-nav-dialog.html',
  styleUrls: ['./version-nav.component.css']
})

export class VersionNavDialogComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  isOpen: boolean;
  highlightedRows = [];

  showColumns: string[] = ['message', 'datatime'];
  showColumnsM: string[] = [ 'message', 'datatime'];
  mainDataSource = new Array<MainVersionResponse>();
  showDataSource = new MatTableDataSource<VersionResponse>();

  selection = new SelectionModel<VersionResponse>(true, []);

  selectedFiles: File;
  textMessage: string;

  constructor(public dialogRef: MatDialogRef<VersionNavDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private http: HttpClient,
              private versionservice: VersionService,
              public dialog: MatDialog ) {
  }

  addVersionDialog(): void {
      const dialogRef2 = this.dialog.open(MessageDialogComponent, {
        width: '250px',
        data: {textMessage: this.textMessage}
      });

      dialogRef2.afterClosed().subscribe(result => {
        if (result) {
          if (this.selectedFiles) {
            this.versionservice.add_version(this.data, this.selectedFiles, result ).subscribe( res => {
              this.getFiles();
              this.RefreshTable.emit();
            });
          }
        }
      });
  }

  ngOnInit() {
    this.getFiles();
  }

  onNoClick(): void {
    console.log('close');
    this.dialogRef.close();
  }

  clickFile(row) {
    if (!this.isOpen) {
      this.selection.toggle(row);
      this.isOpen = false;
    }
    this.isOpen = false;
  }

  /* Otwieranie plików */
  openFile(myname) {
    this.isOpen = true;
    this.selection.clear();
    const myfile = this.mainDataSource.find(x => x.message === myname.message).uid;
    const myfile2 = this.mainDataSource.find(x => x.message === myname.message);
    const tabWindowId = window.open('about:blank', '_blank');
    this.versionservice.get_version_and_show(myfile).subscribe(
      (val: BinaryType) => {
        const byteC = atob(val);
        const byteN = new Array(byteC.length);
        for (let i = 0; i < byteC.length; i++) {
          byteN[i] = byteC.charCodeAt(i);
        }
        const byteA = new Uint8Array(byteN);
        const b = new Blob([byteA], { type: myfile2.fileExtension });
        const fileURL = URL.createObjectURL(b);
        tabWindowId.location.href = fileURL;
        this.highlightedRows = [];
        this.selection.clear();
      });
  }

  usunWersje() {
    if (this.selection.selected.length === 1) {
      const selFiles: any = [];
      this.mainDataSource.forEach( i => {
        this.selection.selected.forEach(y => {
          if (i.datatime === y.datatime) {
            selFiles.push(i.uid);
          }
        });
      });

      this.versionservice.delete_version(selFiles).subscribe(
        result => {
          this.getFiles();
        }
      );
    }
  }

  downloadFile() {
    if (this.selection.selected.length === 1) {
      const selFiles: any = [];
      this.mainDataSource.forEach(i => {
        this.selection.selected.forEach(y => {
          if (i.datatime === y.datatime) {
            selFiles.push(i.uid);
          }
        });
      });

      this.versionservice.download_version(selFiles).subscribe(result => {
          if (selFiles.length === 1) {
            this.versionservice.download_version(selFiles).subscribe((o: HttpResponse<any>) => {
              this.mySaveFiles(o);
              this.getFiles();
            });
          }
        }
      );
    }
  }

  sethighlightedRows(row) {
    if (this.highlightedRows.includes(row)) {
      const newarray = [];
      this.highlightedRows.forEach(o => {
        if (o !== row) {
          newarray.push(o);
        }
      });
      this.highlightedRows = newarray;
    } else {
      this.highlightedRows.push(row);
    }
  }

  mySaveFiles(o: any) {
    const ResponseName = o.headers.get('name');
    const ResponseType = o.headers.get('typ');
    const byteC = atob(o.body);
    const byteN = new Array(byteC.length);

    for (let i = 0; i < byteC.length; i++) {
      byteN[i] = byteC.charCodeAt(i);
    }
    const byteA = new Uint8Array(byteN);
    const ablob = new Blob([byteA], {type: ResponseType});
    const aname = ResponseName;
    importedSaveAs(ablob, aname);
  }

  getFiles() {
    this.selection.clear();
    this.versionservice.get_version(this.data).subscribe(
      result => {
        this.mainDataSource = result.versions;
        this.makeShowDataSource(this.mainDataSource);
      }
    );
  }

  /** Tworzenie porządku w tabeli do wyświetlania */
  makeShowDataSource(mainData: Array<MainVersionResponse>) {
    const filesArray = mainData.map(o => {
      return {message: o.message, datatime: o.datatime};

    });
    this.showDataSource = new MatTableDataSource<VersionResponse>(filesArray);
  }

  onFileSelected(event) {
    this.selectedFiles = event.target.files[0];
    if (!this.selectedFiles) {
      this.addVersionDialog();
    }
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.showDataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.showDataSource.data.forEach(row => this.selection.select(row));
  }
}

@Component({
  selector: 'app-version-message-dialog',
  templateUrl: './version-message.component.html',
  styleUrls: ['./version-nav.component.css']
})

export class MessageDialogComponent {

  constructor(
    public dialogRef2: MatDialogRef<MessageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    console.log('close');
    this.dialogRef2.close();
  }
}
