import {Component, EventEmitter, Inject, Input,  Output} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../file.service';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatSnackBar} from '@angular/material';


export interface DialogData {
  newName: string;
}

@Component({
  selector: 'app-rename',
  templateUrl: './rename.component.html',
  styleUrls: ['./rename.component.css']
})

export class RenameComponent {
  @Output() RefreshTable = new EventEmitter();
  @Input() files;
  newName: string ;

  constructor(private http: HttpClient,
              private fileservice: FileService,
              public dialog: MatDialog,
              private snackBar: MatSnackBar) { }

  openDialog(): void {
    if (this.files.length === 0 ) {
      return console.log('brak plikow wybranych');
    }

    if (this.files.length === 1) {
      const dialogRef = this.dialog.open(RenameDialogComponent, {
        width: '250px',
        data: {newName: this.newName}
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.fileservice.rename_file(this.files, result).subscribe( res => {
            this.snackBar.open(res.msg, ' ', {duration: 4000});
            this.RefreshTable.emit();
          });
        }
      });
    } else {
      return console.log('za duzo plikow');
    }
  }

  isDis() {
    if (this.files.length === 1) {
      return false;
    } else {
      return true;
    }
  }
}

@Component({
  selector: 'app-rename-dialog',
  templateUrl: './rename-dialog.component.html',
})

export class RenameDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<RenameDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}

