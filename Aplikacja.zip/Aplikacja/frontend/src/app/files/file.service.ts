import { Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable} from 'rxjs';

import { SafeUrl } from '@angular/platform-browser/src/security/dom_sanitization_service';

@Injectable({
  providedIn: 'root'
})

  export class FileService {
    private token: string;
    private WAI: any;

  constructor(private http: HttpClient) {
    this.token = localStorage.getItem('usertoken');
  }

  public add_file(f1: any): Observable<any> {
    const formData = new FormData();
    let x = 0;
    for (const f of f1) {
      formData.append('file' + x, f);
      x++;
    }
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/add_file', formData);
  }

  public add_folder(f1: any): Observable<any> {
    const formData = new FormData();
    let x = 0;
    for (const f of f1) {
      formData.append('file' + x, f);
      x++;
    }
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/add_folder', formData);
  }

  public make_folder(f1: string): Observable<any> {
    const formData = new FormData();
    formData.append('folder', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/make_folder', formData);
  }

  public delete_file(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/delete_file', formData);
  }


  public rename_file(f1: any, n1: string): Observable<any> {
    const formData = new FormData();
    formData.append('file', f1);
    formData.append('newname', n1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/rename_file', formData);
  }

  public get_files(): Observable<any> {
    return this.http.post('/api/get_files ', {xaccesstoken: this.getToken(), wai: this.getWAI()});
  }

  public get_users(): Observable<any> {
    const formData = new FormData();
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_users', formData);
  }

  public download_files(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('files', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/download_files', formData, {
      responseType: 'BinaryType' as 'json',
      observe: 'response',
      headers: ({downloadType: 'regularDownload'})
    });
  }

  public get_names(bodyBreadCrumb: any, lastBreadCrumb: any): Observable<any> {
    const formData = new FormData();
    formData.append('bodyBreadCrumb', bodyBreadCrumb);
    formData.append('lastBreadCrumb', lastBreadCrumb);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_names', formData);
  }

  get_file_and_show(uid: any): Observable<SafeUrl> {
    const formData = new FormData();
    formData.append('uid', uid);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_file_to_show', formData, {
      responseType: 'application/pdf' as 'json'
    });
  }

  private getWAI(): any {
    this.WAI = localStorage.getItem('wai');
    return this.WAI;
  }

  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem('usertoken');
    }
    return this.token;
  }

}
