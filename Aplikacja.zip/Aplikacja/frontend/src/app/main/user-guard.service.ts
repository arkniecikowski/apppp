import { Injectable} from '@angular/core';
import {Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import {AuthenticationService} from '../authentication.service';

@Injectable()
export class UserGuardService implements CanActivate {

  constructor(private auth: AuthenticationService,
              private router: Router) {}

  canActivate() {
    if (!(this.auth.getisAdmin() === true)) {
      return false;
    }
    this.router.navigateByUrl('/admin');
    return true;
  }

}
