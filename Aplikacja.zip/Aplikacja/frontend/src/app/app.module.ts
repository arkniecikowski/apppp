import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import {RouterModule, Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { AuthenticationService} from './authentication.service';
import { LoginComponent } from './login/login.component';
import { ProfilComponent } from './profil/profil.component';
import { AuthGuardService } from './auth-guard.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AddFilesComponent } from './files/add-files/add-files.component';
import { FilesComponent } from './files/files.component';
import {MakeFolderComponent, MakeFolderDialogComponent } from './files/make-folder/make-folder.component';
import {FileService} from './files/file.service';
import {MaterialModule} from './files/material/material.module';
import { ArrayComponent } from './files/array/array.component';
import {DeleteFileComponent, DeleteFileDialogComponent} from './files/delete-file/delete-file.component';
import { BreadcrumbComponent } from './files/breadcrumb/breadcrumb.component';
import {RenameComponent, RenameDialogComponent} from './files/rename/rename.component';
import { DownloadComponent } from './files/download/download.component';
import {VersionNavComponent, VersionNavDialogComponent} from './files/version/version-nav/version-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule, MatSnackBarModule } from '@angular/material';
import { MainComponent } from './main/main.component';
import {MessageDialogComponent} from './files/version/version-nav/version-nav.component';
import { NavTopComponent } from './main/nav-top/nav-top.component';
import { SharedComponent } from './shared/shared.component';
import {SharedFilesComponent, SharedFilesDialogComponent, SharedFilesMessageComponent} from './shared/shared-files/shared-files.component';
import {SharedService} from './shared/shared.service';
import {VersionService} from './files/version/version.service';
import { SharedDownloadComponent } from './shared/shared-download/shared-download.component';
import {SharedDeleteComponent, SharedDeleteDialogComponent} from './shared/shared-delete/shared-delete.component';
import { AdminComponent } from './profil/admin/admin.component';
import { UserComponent } from './profil/user/user.component';
import { ChangePsasComponent } from './profil/user/change-psas/change-psas.component';
import {ChangePassComponent, ChangePassDialogComponent} from './profil/admin/change-pass/change-pass.component';
import {AddUserComponent, AddUserDialogComponent} from './profil/admin/add-user/add-user.component';
import {DeleteUserComponent, DeleteUserDialogComponent} from './profil/admin/delete-user/delete-user.component';
import {ProjectInfoComponent, ProjectInfoDialogComponent} from './profil/admin/project-info/project-info.component';
import { UserGuardService} from './main/user-guard.service';
import { ChangeMyPassDialogComponent} from './profil/user/change-psas/change-psas.component';
import { AddAvatarComponent } from './profil/user/add-avatar/add-avatar.component';
import {ChangeRoleComponent, ChangeRoleDialogComponent} from './profil/admin/change-role/change-role.component';
import { LastaddedComponent } from './lastadded/lastadded.component';
import { LastaddedDownloadComponent } from './lastadded/lastadded-download/lastadded-download.component';
import {LastaddedService} from './lastadded/lastadded.service';
import { FilterComponent } from './files/filter/filter.component';
import { FlexLayoutModule } from '@angular/flex-layout';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'profil',
    component: MainComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'main',
    component: MainComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'shared',
    component: MainComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'latest',
    component: MainComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'admin',
    component: MainComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProfilComponent,
    AddFilesComponent,
    FilesComponent,
    MakeFolderComponent,
    MakeFolderDialogComponent,
    ArrayComponent,
    DeleteFileComponent,
    DeleteFileDialogComponent,
    BreadcrumbComponent,
    RenameComponent,
    RenameDialogComponent,
    DownloadComponent,
    VersionNavComponent,
    VersionNavDialogComponent,
    MainComponent,
    MessageDialogComponent,
    NavTopComponent,
    SharedComponent,
    SharedFilesComponent,
    SharedFilesMessageComponent,
    SharedFilesDialogComponent,
    SharedDownloadComponent,
    SharedDeleteComponent,
    SharedDeleteDialogComponent,
    AdminComponent,
    UserComponent,
    ChangePsasComponent,
    ChangePassComponent,
    AddUserComponent,
    DeleteUserComponent,
    ProjectInfoComponent,
    AddUserDialogComponent,
    ChangeMyPassDialogComponent,
    ChangePassDialogComponent,
    AddAvatarComponent,
    DeleteUserDialogComponent,
    ChangeRoleComponent,
    ChangeRoleDialogComponent,
    LastaddedComponent,
    LastaddedDownloadComponent,
    FilterComponent,
    ProjectInfoDialogComponent
  ],

  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    MaterialModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatSnackBarModule,
    MatListModule,
    ReactiveFormsModule,
    FlexLayoutModule
  ],

  entryComponents: [
    MakeFolderDialogComponent,
    DeleteFileDialogComponent,
    RenameDialogComponent,
    VersionNavDialogComponent,
    MainComponent,
    MessageDialogComponent,
    SharedFilesDialogComponent,
    SharedFilesMessageComponent,
    SharedDeleteDialogComponent,
    AddUserDialogComponent,
    ChangeRoleDialogComponent,
    ChangeMyPassDialogComponent,
    ChangePassDialogComponent,
    DeleteUserDialogComponent,
    ProjectInfoDialogComponent
  ],

  providers: [
    AuthenticationService,
    FileService,
    SharedService,
    VersionService,
    UserGuardService,
    AuthGuardService,
    LastaddedService
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
