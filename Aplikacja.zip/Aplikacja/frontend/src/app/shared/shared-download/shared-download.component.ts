import {Component, EventEmitter, Input, Output} from '@angular/core';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {SharedService} from '../shared.service';
import {saveAs as importedSaveAs} from 'file-saver';


@Component({
  selector: 'app-shared-download',
  templateUrl: './shared-download.component.html',
  styleUrls: ['./shared-download.component.css']
})
export class SharedDownloadComponent  {
  @Input() files;
  @Output() RefreshTable = new EventEmitter();
  @Output() Loading = new EventEmitter();

  constructor(private http: HttpClient, private sharedService: SharedService) { }

  downloadFile() {
    this.Loading.emit();
    return this.sharedService.download_shared_filed(this.files).subscribe((o: HttpResponse<any>) => {
      this.mySaveFiles(o);
      this.Loading.emit();
      this.RefreshTable.emit();
    }, error1 => {
      console.log(error1);
    });
  }

  mySaveFiles(o: any) {
    const ResponseName = o.headers.get('name');
    const ResponseType = o.headers.get('typ');
    const byteC = atob(o.body);
    const byteN = new Array(byteC.length);

    for (let i = 0; i < byteC.length; i++) {
      byteN[i] = byteC.charCodeAt(i);
    }
    const byteA = new Uint8Array(byteN);
    const ablob = new Blob([byteA], {type: ResponseType});
    const aname = ResponseName;

    importedSaveAs(ablob, aname);
  }

}
