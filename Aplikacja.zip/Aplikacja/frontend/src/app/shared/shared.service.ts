import {ChangeDetectorRef, Injectable, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable, of} from 'rxjs';

import { SafeUrl } from '@angular/platform-browser/src/security/dom_sanitization_service';

@Injectable({
  providedIn: 'root'
})

export class SharedService {
  private token: string;
  private WAI: any;

  constructor(private http: HttpClient) {
    this.token = localStorage.getItem('usertoken');
  }

  get_shared_show(uid: any): Observable<SafeUrl> {
    const formData = new FormData();
    formData.append('uid', uid);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_shared_show', formData, {
      responseType: 'application/pdf' as 'json'
    });
  }

  public get_shared_files(): Observable<any> {
    const formData = new FormData();
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/get_shared_files', formData);
  }

  public add_shared_files(files: any, users: any): Observable<any> {
    const formData = new FormData();
    formData.append('files', files);
    formData.append('users', users);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/add_shared_files', formData);
  }

  public download_shared_filed(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('files', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/download_files', formData, {
      responseType: 'BinaryType' as 'json',
      observe: 'response',
      headers: ({downloadType: 'sharedDownload'})
    });
  }

  public delete_shared_files(f1: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', f1);
    formData.append('xaccesstoken', this.getToken());
    formData.append('wai', this.getWAI());
    return this.http.post('/api/delete_shared_files', formData);
  }

  private getWAI(): any {
    this.WAI = localStorage.getItem('wai');
    return this.WAI;
  }

  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem('usertoken');
    }
    return this.token;
  }
}
