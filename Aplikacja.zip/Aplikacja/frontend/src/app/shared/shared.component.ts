import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Subject} from 'rxjs';
import {MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {SharedService} from './shared.service';

export interface LiteResponse  {
  name: string;
  owner: string;
  datatime: string;
}

export interface MainResponse {
  uid: string;
  name: string;
  datatime: string;
  isFolder: boolean;
  fileExtension: string;
  owner: string;
}

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html',
  styleUrls: ['./shared.component.css']
})
export class SharedComponent implements OnInit {
  @Output() isSelected = new EventEmitter();
  @Output() OpenGallery = new EventEmitter();
  @Output() ReloadGallery = new EventEmitter();
  @Output() cellClick: EventEmitter<any> = new EventEmitter();
  private eventFolderOtwarty: Subject<void> = new Subject<void>();

  load = false;
  color = 'primary';
  mode = 'indeterminate';
  value = 50;
  bufferValue = 75;

  highlightedRows = [];
  isOpen: boolean;
  showColumns: string[] = ['name', 'owner', 'datatime'];
  showColumnsM: string[] = ['name'];
  mainDataSource = new Array<MainResponse>();
  showDataSource = new MatTableDataSource<LiteResponse>();

  selection = new SelectionModel<LiteResponse>(true, []);

  constructor(private sharedService: SharedService) {
  }

  ngOnInit(): void {
    this.getFiles();
  }

  RefreshSelectedAndNav() {
    this.isSelected.emit(false);
    this.getFiles();
  }

  getshowDataSource() {
    return this.showDataSource;
  }

  ifFolder(element) {
    let ifFol = false;
    this.mainDataSource.forEach( i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.isFolder) {
          ifFol = true;
        }
      }
    });
    return ifFol;
  }

  ifText(element) {
    let ifFol = false;
    let aArray;
    this.mainDataSource.forEach( i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.fileExtension !== null) {
          aArray = i.fileExtension.split('/');
          if (aArray[0] === 'text') {
            ifFol = true;
          }
        }
      }
    });
    return ifFol;
  }

  ifImage(element) {
    let ifFol = false;
    let aArray;
    this.mainDataSource.forEach(i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.fileExtension !== null) {
          aArray = i.fileExtension.split('/');
          if (aArray[0] === 'image') {
            ifFol = true;
          }
        }
      }
    });
    return ifFol;
  }

  ifVideo(element) {
    let ifFol = false;
    let aArray;
    this.mainDataSource.forEach(i => {
      if (i.name === element.name && i.datatime === element.datatime) {
        if (i.fileExtension !== null) {
          aArray = i.fileExtension.split('/');
          if (aArray[0] === 'video') {
            ifFol = true;
          }
        }
      }
    });
    return ifFol;
  }

  getSelectedFilesUID() {
    const start = [];
    const selFiles: any = [];
    try {
      this.mainDataSource.forEach( i => {
        this.selection.selected.forEach(y => {
          if (i.name === y.name && i.owner === y.owner) {
            selFiles.push(i.uid);
          }
        });
      });
      return selFiles;
    } catch (e) {
      return start;
    }
  }

  /* UID zaznaczonych plików */
  getSelectedFilesisFolder() {
    const start = [];
    const selFiles: any = [];
    try {
      this.mainDataSource.forEach( i => {
        this.selection.selected.forEach(y => {
          if (i.name === y.name && i.datatime === y.datatime) {
            selFiles.push(i.isFolder);
          }
        });
      });
      return selFiles;
    } catch (e) {
      return start;
    }
  }

  /* Pobierz pliki */
getFiles() {
    this.selection.clear();
    this.setLoad();
    this.sharedService.get_shared_files().subscribe(
      result => {
      this.setLoad();
      this.mainDataSource = result.files;
      this.makeShowDataSource(this.mainDataSource);
    }
   );
}

  sethighlightedRows(row) {
    if (this.highlightedRows.includes(row)) {
      const newarray = [];
      this.highlightedRows.forEach(o => {
        if (o !== row) {
          newarray.push(o);
        }
      });
      this.highlightedRows = newarray;
    } else {
      this.highlightedRows.push(row);
    }
  }

  /** Tworzenie porządku w tabeli do wyświetlania */
  makeShowDataSource(mainData: Array<MainResponse>) {
   try {
     const foldersArray = mainData.filter(o =>
       o.isFolder === true).map(o => {
       return {name: o.name, datatime: o.datatime, owner: o.owner};
     });
     const filesArray = mainData.filter(o =>
       o.isFolder === false).map(o => {
       return {name: o.name, datatime: o.datatime, owner: o.owner };
     });
     const newArray = foldersArray.concat(filesArray);
     this.showDataSource = new MatTableDataSource<LiteResponse>(newArray);
   } catch (e) {
    }
  }


  /* Otwieranie plików */
  openFile(myname) {
    this.isOpen = true;
    this.selection.clear();
    const myfile = this.mainDataSource.find(x => x.name === myname.name).uid;
    const myfile2 = this.mainDataSource.find(x => x.name === myname.name);
    let tabWindowId;
    if (!myfile2.isFolder) {
      tabWindowId = window.open('about:blank', '_blank');
    }
    this.sharedService.get_shared_show(myfile).subscribe(
      (val: BinaryType) => {
        if (myfile2.isFolder) {
          const newwai = JSON.parse(val).wai;
          localStorage.setItem('wai', newwai);
          this.ReloadGallery.emit();
          this.getFiles();
          this.eventFolderOtwarty.next();
        } else {
          const byteC = atob(val);
          const byteN = new Array(byteC.length);
          for (let i = 0; i < byteC.length; i++) {
            byteN[i] = byteC.charCodeAt(i);
          }
          const byteA = new Uint8Array(byteN);
          const b = new Blob([byteA], { type: myfile2.fileExtension });
          const fileURL = URL.createObjectURL(b);
          tabWindowId.location.href = fileURL;
        }
        this.highlightedRows = [];
        this.selection.clear();
        this.isSelected.emit(false);
      });
  }


  setLoad() {
    if (this.load === false) {
      this.load = true;
    } else {
      this.load = false;
    }
  }
  /* Brak zaznaczenia checkboxu przy kliknięciu w plik   */
  clickFile(row) {
    if (!this.isOpen) {
      this.selection.toggle(row);
      this.isOpen = false;
    }
    this.isOpen = false;
    this.isSelected.emit(this.selection.hasValue());
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.showDataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.showDataSource.data.forEach(row => this.selection.select(row));
  }

}
