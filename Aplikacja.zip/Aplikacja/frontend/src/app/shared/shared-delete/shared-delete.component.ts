import {Component, EventEmitter, Inject, Input, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {HttpClient} from '@angular/common/http';
import {SharedService} from '../shared.service';

@Component({
  selector: 'app-shared-delete',
  templateUrl: './shared-delete.component.html',
  styleUrls: ['./shared-delete.component.css']
})
export class SharedDeleteComponent  {
  @Output() RefreshTable = new EventEmitter();
  @Input() files;

  constructor(private http: HttpClient,
              private sharedService: SharedService,
              public dialog: MatDialog) { }

  openDialog(): void {

    const dialogRef = this.dialog.open(SharedDeleteDialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log(this.files);
        this.sharedService.delete_shared_files(this.files).subscribe( res => {
          this.RefreshTable.emit();
        });
      } else {
        this.RefreshTable.emit();
      }
    });
  }

}

@Component({
  selector: 'app-shared-delete-dialog',
  templateUrl: './shared-delete-dialog.html',
})

export class SharedDeleteDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<SharedDeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
