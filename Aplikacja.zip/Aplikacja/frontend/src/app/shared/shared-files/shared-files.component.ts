import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatTableDataSource} from '@angular/material';
import {HttpClient} from '@angular/common/http';
import {FileService} from '../../files/file.service';
import {SelectionModel} from '@angular/cdk/collections';
import {SharedService} from '../shared.service';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-shared-files',
  templateUrl: './shared-files.component.html',
  styleUrls: ['./shared-files.component.css']
})
export class SharedFilesComponent  {
  @Input() files;
  @Input() fileisFolder;
  @Output() RefreshTable = new EventEmitter();

  constructor(public dialog: MatDialog) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(SharedFilesDialogComponent, {
      width: '80%',
      data: this.files
    });

    dialogRef.afterClosed().subscribe(result => {
      this.RefreshTable.emit();
    });
  }
}

export interface LiteResponse  {
  select: any;
  name: string;
  role: string;
}

export interface MainResponse {
  name: string;
  role: string;
  public_id: string;
  select: string;
}

@Component({
  selector: 'app-shared-files-dialog',
  templateUrl: './shared-files-dialog.html',
  styleUrls: ['./shared-files.component.css']

})

export class SharedFilesDialogComponent implements OnInit {
  @Output() RefreshTable = new EventEmitter();
  isOpen: boolean;
  highlightedRows = [];

  showColumns: string[] = ['select', 'name', 'role'];
  showColumnsM: string[] = ['select', 'name'];
  mainDataSource = new Array<MainResponse>();
  showDataSource = new MatTableDataSource<LiteResponse>();
  selection = new SelectionModel<LiteResponse>(true, []);
  selectedFiles: File;
  textMessage: string;

  constructor(public dialogRef: MatDialogRef<SharedFilesDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private http: HttpClient,
              private fileservice: FileService,
              private sharedService: SharedService,
              public dialog: MatDialog,
              private sanitizer: DomSanitizer) {
  }

  addsharedFiles(): void {
    if (this.getPubID().length !== 0) {
      const dialogRef2 = this.dialog.open(SharedFilesMessageComponent, {
        width: '250px',
        data: {textMessage: this.textMessage}
      });

      this.dialog.afterAllClosed.subscribe(o => {
        this.RefreshTable.emit();
      });

      dialogRef2.afterClosed().subscribe(result => {
        if (result) {
          this.sharedService.add_shared_files(this.data, this.getPubID()).subscribe( res => {
            console.log(res);
            this.dialog.closeAll();
            this.dialogRef.close();
            this.RefreshTable.emit();
          });
        }
      });
    }
  }

  getPubID() {
    const selFiles: any = [];
    this.mainDataSource.forEach( i => {
      this.selection.selected.forEach(y => {
        if (i.name === y.name) {
          selFiles.push(i.public_id);
        }
      });
    });
    return selFiles;
  }

  ngOnInit() {
    this.getFiles();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  clickFile(row, i) {
    if (!this.isOpen) {
      this.selection.toggle(row);
      this.isOpen = false;
    }
    this.isOpen = false;
  }

  sethighlightedRows(row) {
    if (this.highlightedRows.includes(row)) {
      const newarray = [];
      this.highlightedRows.forEach(o => {
        if (o !== row) {
          newarray.push(o);
        }
      });
      this.highlightedRows = newarray;
    } else {
      this.highlightedRows.push(row);
    }
  }

  getFiles() {
    this.selection.clear();
    this.fileservice.get_users().subscribe(
      result => {
        console.log(result.users);
        this.mainDataSource = result.users;
        this.makeShowDataSource(this.mainDataSource);
      }
    );
  }

  makeShowDataSource(mainData: Array<MainResponse>) {
    const filesArray = mainData.map(o => {
      const ns = this.sanitizer.bypassSecurityTrustUrl(o.select);
      return {select: ns, name: o.name, role: o.role};
    });
    this.showDataSource = new MatTableDataSource<LiteResponse>(filesArray);
  }

  onFileSelected(event) {
    this.selectedFiles = event.target.files[0];
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.showDataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.showDataSource.data.forEach(row => this.selection.select(row));
  }
}


@Component({
  selector: 'app-shared-files-message-dialog',
  templateUrl: './shared-files-message.component.html',
  styleUrls: ['./shared-files.component.css']
})

export class SharedFilesMessageComponent {
  constructor(
    public dialogRef2: MatDialogRef<SharedFilesMessageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef2.close();
  }
}
